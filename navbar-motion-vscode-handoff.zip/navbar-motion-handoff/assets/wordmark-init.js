/* Load after wordmark-shapes.js, wordmark-settings.js and wordmark-motion.js. */
(() => {
  const start = () => window.AKWordmark?.initAll(document);
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", start, { once: true });
  } else start();
})();
